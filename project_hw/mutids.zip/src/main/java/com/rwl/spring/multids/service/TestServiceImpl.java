package com.rwl.spring.multids.service;

import com.rwl.spring.multids.dao.second.Test2VOMapper;
import com.rwl.spring.multids.dao.master.TestVOMapper;
import com.rwl.spring.multids.entity.Test2VO;
import com.rwl.spring.multids.entity.TestVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@Service
public class TestServiceImpl {

    @Resource(name="transactionManager")
    private DataSourceTransactionManager transactionManager;

    @Autowired
    private TestVOMapper testVOMapper;

    @Autowired
    private Test2VOMapper test2VOMapper;

    @Transactional
    public int insertTestVO(TestVO testVO) {
        return testVOMapper.insert(testVO);
    }

    @Transactional
    public int insertTest2VO(Test2VO test2VO) {
        return test2VOMapper.insert(test2VO);
    }

    @Transactional
    public int insertTestAndTest2(TestVO testVO, Test2VO test2VO, boolean error1, boolean error2) {
        testVOMapper.insert(testVO);
        if (error1 == true) {
            throw new RuntimeException("测试error1 错误");
        }
        test2VOMapper.insert(test2VO);
        if (error2 == true) {
            throw new RuntimeException("测试error2 错误");
        }
        return 1;
    }


}

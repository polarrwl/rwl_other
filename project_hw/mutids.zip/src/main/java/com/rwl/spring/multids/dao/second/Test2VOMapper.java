package com.rwl.spring.multids.dao.second;

import com.rwl.spring.multids.entity.Test2VO;

public interface Test2VOMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Test2VO record);

    int insertSelective(Test2VO record);

    Test2VO selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Test2VO record);

    int updateByPrimaryKey(Test2VO record);
}
package com.rwl.spring.multids.controller;

import com.rwl.spring.multids.entity.Test2VO;
import com.rwl.spring.multids.entity.TestVO;
import com.rwl.spring.multids.param.TestParamVO;
import com.rwl.spring.multids.service.TestServiceImpl;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/test")
@Api("测试通过RestTemplate调用")
public class TestController {

    @Autowired
    private TestServiceImpl testService;

    @GetMapping("/testget")
    public String testGet(String _str) {
        System.out.println(_str);
        return "OK"+_str;
    }

    @PostMapping("/testpost")
    public int testPost(@RequestBody TestParamVO testParamVO) {
        int flag01 = testService.insertTestVO(testParamVO.getTestVO());
        int flag02 = testService.insertTest2VO(testParamVO.getTest2VO());
        return 0;
    }


    @PostMapping("/testpostall")
    public int testPostAll(@RequestBody TestParamVO testParamVO) {
        return testService.insertTestAndTest2(testParamVO.getTestVO(),
                testParamVO.getTest2VO(),
                testParamVO.isError1(),
                testParamVO.isError2());
    }

}

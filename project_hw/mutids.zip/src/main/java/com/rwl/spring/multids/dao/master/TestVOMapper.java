package com.rwl.spring.multids.dao.master;


import com.rwl.spring.multids.entity.TestVO;

public interface TestVOMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TestVO record);

    int insertSelective(TestVO record);

    TestVO selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TestVO record);

    int updateByPrimaryKey(TestVO record);
}
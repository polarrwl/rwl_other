package com.rwl.spring.multids.param;

import com.rwl.spring.multids.entity.Test2VO;
import com.rwl.spring.multids.entity.TestVO;

public class TestParamVO {
    private TestVO testVO;
    private Test2VO test2VO;
    private boolean error1;
    private boolean error2;

    public TestVO getTestVO() {
        return testVO;
    }

    public void setTestVO(TestVO testVO) {
        this.testVO = testVO;
    }

    public Test2VO getTest2VO() {
        return test2VO;
    }

    public void setTest2VO(Test2VO test2VO) {
        this.test2VO = test2VO;
    }

    public boolean isError1() {
        return error1;
    }

    public void setError1(boolean error1) {
        this.error1 = error1;
    }

    public boolean isError2() {
        return error2;
    }

    public void setError2(boolean error2) {
        this.error2 = error2;
    }
}

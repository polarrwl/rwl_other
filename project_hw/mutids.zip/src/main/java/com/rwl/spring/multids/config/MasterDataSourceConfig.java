package com.rwl.spring.multids.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.rwl.rcloud.core.crypt.RCloudEncryptUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.io.UnsupportedEncodingException;

/**
 * 主数据源
 * 注意：basePackages这里配置的数据源package包跟SecondDataSource中配置的不能是相同目录或者子目录中，不然mapper对应的数据源会被覆盖掉
 */
@Configuration
@MapperScan(basePackages = MasterDataSourceConfig.MAPPER_PACKAGE, sqlSessionFactoryRef = "masterSqlSessionFactory")
public class MasterDataSourceConfig {

    protected static final String MAPPER_PACKAGE = "com.rwl.spring.multids.dao.master";
    protected static final String MAPPER_PATH_XML = "classpath:com/rwl/spring/multids/dao/master/*.xml";

    private DataSource maserDataSource;

    /**
     * 主数据源配置
     * spring.datasource.driverClassName=com.mysql.jdbc.Driver
     * spring.datasource.url=jdbc:mysql://xxxxx
     * spring.datasource.username=xxxx
     * spring.datasource.password=xxxx
     * @return
     * @throws UnsupportedEncodingException
     */
    @ConfigurationProperties(prefix = "spring.datasource", ignoreNestedProperties = true)
    @Bean(name = "masterDataSource")
    @Primary
    public DataSource maserDataSource() {
        this.maserDataSource = new DruidDataSource();
        return this.maserDataSource;
    }

    @Bean(name = "masterTransactionManager")
    @Primary
    public DataSourceTransactionManager masterTransactionManager() {
        return new DataSourceTransactionManager(maserDataSource());
    }

    @Bean(name = "masterSqlSessionFactory")
    @Primary
    public SqlSessionFactory masterSqlSessionFactory(DataSource masterDataSource)
            throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(masterDataSource);
        sessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources(MAPPER_PATH_XML));
        return sessionFactory.getObject();
    }

}

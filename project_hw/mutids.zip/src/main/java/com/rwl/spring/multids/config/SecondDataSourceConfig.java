package com.rwl.spring.multids.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.io.UnsupportedEncodingException;

/**
 * 第二数据源
 * 注意：basePackages这里配置的数据源package包跟MasterDataSource中配置的不能是相同目录或者子目录中，不然mapper对应的数据源会被覆盖掉
 */
@Configuration
@MapperScan(basePackages = SecondDataSourceConfig.MAPPER_PACKAGE, sqlSessionFactoryRef = "secondSqlSessionFactory")
public class SecondDataSourceConfig {

    protected static final String MAPPER_PACKAGE = "com.rwl.spring.multids.dao.second";
    protected static final String MAPPER_PATH_XML = "classpath:com/rwl/spring/multids/dao/second/*.xml";

    private DataSource secondDataSource;

    /**
     * 主数据源配置
     * spring.datasource.second.driverClassName=com.mysql.jdbc.Driver
     * spring.datasource.second.url=jdbc:mysql://xxxxx
     * spring.datasource.second.username=xxxx
     * spring.datasource.second.password=xxxx
     * @return
     * @throws UnsupportedEncodingException
     */
    @ConfigurationProperties(prefix = "spring.datasource.second", ignoreNestedProperties = true)
    @Bean(name="secondDataSource")
    public DataSource secondDataSource() {
        this.secondDataSource = new DruidDataSource();
        return this.secondDataSource;
    }

    @Bean(name = "secondTransactionManager")
    public DataSourceTransactionManager secondTransactionManager() {
        return new DataSourceTransactionManager(secondDataSource());
    }

    @Bean(name = "secondSqlSessionFactory")
    public SqlSessionFactory secondSqlSessionFactory(@Qualifier("secondDataSource") DataSource secondDataSource)
            throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(secondDataSource);
        sessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources(SecondDataSourceConfig.MAPPER_PATH_XML));
        return sessionFactory.getObject();
    }

}
